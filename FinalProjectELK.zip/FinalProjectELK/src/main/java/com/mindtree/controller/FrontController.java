package com.mindtree.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.context.annotation.RequestScope;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class FrontController {

	@RequestMapping("/")
	public ModelAndView getWine(HttpServletRequest request) {
		ModelAndView mv= new ModelAndView();
		
		String name = request.getParameter("name");
		
		
		mv.addObject("name",name);
		mv.setViewName("index.jsp");
		return mv;
	}
	
	@RequestMapping("/getResult")
	public ModelAndView getResult(HttpServletRequest request) {
		ModelAndView mv= new ModelAndView();
		
		
		mv.setViewName("index.jsp");
		return mv;
	}
	
	
}
