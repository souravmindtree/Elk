package com.mindtree;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinalProjectElkApplication {

	public static void main(String[] args) {
		SpringApplication.run(FinalProjectElkApplication.class, args);
	}

}

